const express = require('express');
const mongoose = require('mongoose');
const expressSession = require("express-session")

const User = require('./userschema');

const app = express();
const port = 3000;

const web = `${__dirname}/web`
const images = `${__dirname}/images`
const resources = `${__dirname}/resources`

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(expressSession({secret:"secret",resave:false,saveUninitialized:false}))
app.use(express.static(web));
app.use(express.static(images));
app.use(express.static(resources));

mongoose.connect('mongodb+srv://pranshul:pranshul123@cluster0.znapaw3.mongodb.net/mydb', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Successfully Connected to MongoDb")
    })
    .catch((err) => {
        console.log("Error connecting to mongoDb: ", err)
    })

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.get('/welcome',(req,res)=>{
    res.sendFile(`${web}/welcome.html`);
});

app.get('/add',(req,res)=>{
    res.sendFile(`${web}/add.html`)
})

app.get('/delete',(req,res)=>{
    res.sendFile(`${web}/delete.html`)
})

app.get('/light',(req,res)=>{
    res.sendFile(`${web}/lighting.html`)
})

app.get('/ac',(req,res)=>{
    res.sendFile(`${web}/ac.html`)
})

app.get('/security',(req,res)=>{
    res.sendFile(`${web}/security.html`)
})

app.get('/',(req,res)=>{
    res.redirect('/login');
})

app.get('/login',(req,res)=>{
    res.sendFile(`${web}/login.html`)
})

app.get('/register',(req,res)=>{
    res.sendFile(`${web}/register.html`)
})

app.post('/register', async(req, res) => {
    const user = await User.findOne({username:req.body.username});

    if(user) return res.status(400).send("user already exist! ");

    const newUser = await User.create(req.body);
    res.redirect('/welcome');
})

app.post('/login',async(req,res)=>{
    const user = await User.findOne({username:req.body.username});
    const password = req.body.password;
    if(user){
        if(user.password != password) return res.status(400).send("password not matching");
        else{

            res.redirect('/welcome');
        }
    }
    else{
        res.redirect('/register');
    }
})

// function isAuthenticated(req, res, next) {
//     if (req.session && req.session.isAuthenticated) {
//         console.log("sd");
//         return next();
//     }

//     res.redirect('/login'); 
// }


app.listen(port,()=>{
    console.log(`Server Started On http://localhost:${port}`);
})